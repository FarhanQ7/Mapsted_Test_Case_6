import java.util.ArrayList;

public class UsageStatistics
{
	//Class attribute
    private ArrayList<SessionInfos> session_infos;
//getter
    public ArrayList<SessionInfos> getSessionInfos() { return this.session_infos; }
//setter
    public void setSessionInfos(ArrayList<SessionInfos> session_infos) { this.session_infos = session_infos; }
}