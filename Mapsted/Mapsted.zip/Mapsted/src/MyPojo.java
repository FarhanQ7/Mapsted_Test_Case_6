public class MyPojo
{
	
	//Class attributes
    private String manufacturer;
    private String market_name;
    private String codename;
    private String model;
    private UsageStatistics usage_statistics;
    
    
    
    
//getter
    public String getManufacturer() { return this.manufacturer; }
//setter
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }

    
  //getter
    public String getMarketName() { return this.market_name; }
  //setter
    public void setMarketName(String market_name) { this.market_name = market_name; }

    
  //getter
    public String getCodename() { return this.codename; }
  //setter
    public void setCodename(String codename) { this.codename = codename; }

    
  //getter
    public String getModel() { return this.model; }
  //setter
    public void setModel(String model) { this.model = model; }

    
  //getter
    public UsageStatistics getUsageStatistics() { return this.usage_statistics; }
  //setter
    public void setUsageStatistics(UsageStatistics usage_statistics) { this.usage_statistics = usage_statistics; }
}
